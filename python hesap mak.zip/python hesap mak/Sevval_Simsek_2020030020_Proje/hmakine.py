# -*- coding: utf-8 -*-
"""
Created on Sun May  9 14:52:54 2021

@author: şule
"""

import tkinter as tk  #tkinter kütüphanemizi yeni kısa bir ad  ile importladık.

def topla():
    if sayi1.get().isdigit() and sayi3.get():
        s1=int(sayi1.get())
        s2=int(sayi2.get())
        s3=int(sayi3.get())
        sonuc.configure(text=str(s1+s2+s3))
        
# def ile toplama fonksiyonunu  gerçekleştirdik. 3 sayıyı da burada int olarak tanımladık.
#int değerinde tanımlama yaptığımız için noktalı sayılar ile işlem yapılamaz.
# Kullanıcı 2 sayı toplamak istediğinde 3. sayı girme kutusunda sıfır yazarsa 3 lü sayı  sisteminde 2 sayı toplayabilir.
#configure ile sonuçtaki metinsel ifadeyi işlem yapıldığında çıkan sonucu text'e çevirerek yazdırır.

 
        
        
def cikar():
    if sayi1.get().isdigit() and sayi2.get():
        s1=int(sayi1.get())
        s2=int(sayi2.get())        
        sonuc.configure(text=str(s1-s2))
# def ile çıkarma fonksiyonunu  gerçekleştirdik. 2 sayıyı da burada int olarak tanımladık. 
#int değerinde tanımlama yaptığımız için noktalı sayılar ile işlem yapılamaz.
#configure ile sonuçtaki metinsel ifadeyi işlem yapıldığında çıkan sonucu text'e çevirerek yazdırır.

def carpma():
    if sayi1.get().isdigit() and sayi3.get():
        s1=int(sayi1.get())
        s2=int(sayi2.get())
        s3=int(sayi3.get())
        sonuc.configure(text=str(s1*s2*s3))
        
# def ile çarpma fonksiyonunu  gerçekleştirdik. 3 sayıyı da burada int olarak tanımladık.
# Burada 3 sayı belirledim. Eğer kullanıcı 2 sayı çarpmak istiyorsa 3. sayı girme kutusuna 1(bir) yazarak etkisiz eleman olarak kullanabilir.        
#configure ile sonuçtaki metinsel ifadeyi işlem yapıldığında çıkan sonucu text'e çevirerek yazdırır.   
        
def bolme():
    if sayi1.get().isdigit() and sayi2.get():
        s1=int(sayi1.get())
        s2=int(sayi2.get())     
        sonuc.configure(text=str(s1/s2))
        
# def ile bölme fonksiyonunu  gerçekleştirdik. 3 sayıyı da burada int olarak tanımladık.        
#int değerinde tanımlama yaptığımız için noktalı sayılar ile işlem yapılamaz.
#configure ile sonuçtaki metinsel ifadeyi işlem yapıldığında çıkan sonucu text'e çevirerek yazdırır.

ekran = tk.Tk()#ekranımızı tkinter ile yapmaya başladık.
ekran.title('3 Sayılı H.Makinesi')#ekran çerçevemizin başlığını belirledik.

ekran.geometry("270x320")#ekranın boyutunu belirledik.

sonuc = tk.Label(ekran, text="Sonuc",font="Courier 16 bold", width=30, justify="center",fg="red")
# sonuc yazısının ekranda görüneceği karakteristik özelliklerini belirledik.

sonuc.place(x=-70, y=20)
# sonuc yazısını ekrana yerleşim konumunu gerçekleştirdik..

sayi1 = tk.Entry(ekran,  width=30, justify="right", background="light blue")
# 1. sayı kutusunun ekranda görüneceği karakteristik özelliklerini belirledik.

sayi1.place(x=40, y=50)
#1. sayı kutusunun ekrandaki yerleşim konumunu gerçekleştirdik.Soldan 40 yukarıdan 50 cm hareket eder

sayi2 = tk.Entry(ekran, width=30, justify="right",background="light blue")
# 2. sayı kutusunun ekranda görüneceği karakteristik özelliklerini belirledik.

sayi2.place(x=40, y=80) 
# 2. sayı kutusunun ekrandaki yerleşim konumunu gerçekleştirdik.

sayi3 = tk.Entry(ekran, width=30, justify="right",background="light blue")
# 3. sayı kutusunun ekranda görüneceği karakteristik özelliklerini belirledik

sayi3.place(x=40, y=110)
#3.sayı kutusunun ekrandaki yerleşim konumunu gerçekleştirdik. 

arti = tk.Button(ekran, text="+", width=15, command=topla)
#artı tuşunun ekranda boyutunu karakteristik özelliklerini belirledik.
#Tuşa basıldığında işlemi gerçekleştirmesi için command kullandık.

arti.place(x=70, y=150)
#artı tuşunun ekranda yerleşim konumunu gerçekleştirdik.

eksi = tk.Button(ekran, text="-",  width=15, command=cikar)
#eksi tuşunun ekranda boyutunu ve karakteristik özelliklerini belirledik.
#Tuşa basıldığında işlemi gerçekleştirmesi için command kullandık.

eksi.place(x=70, y=190)
#artı tuşunun ekranda yerleşim konumunu gerçekleştirdik.

carpi = tk.Button(ekran, text="*",  width=15, command=carpma)
#çarpı tuşunun ekranda boyutunu ve karakteristik özelliklerini belirledik.
#Tuşa basıldığında işlemi gerçekleştirmesi için command kullandık.

carpi.place(x=70, y=230)
#çarpı tuşunun ekranda yerleşim konumunu gerçekleştirdik. 

bölü = tk.Button(ekran, text="/", width=15, command=bolme)
#bölme tuşunun ekranda boyutunu ve karakteristik özelliklerini belirledik.
#Tuşa basıldığında işlemi gerçekleştirmesi için command kullandık.

bölü.place(x=70, y=270)
#bölü tuşunun ekranda yerleşim konumunu gerçekleştirdik.  


ekran.mainloop()
